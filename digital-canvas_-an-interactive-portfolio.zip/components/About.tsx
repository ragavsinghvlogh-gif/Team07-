
import React from 'react';

const skills = ['React', 'TypeScript', 'Node.js', 'Tailwind CSS', 'Next.js', 'Figma', 'Gemini API'];

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 sm:py-24">
      <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">About Me</h2>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-12 items-center">
        <div className="md:col-span-2">
          <img
            src="https://picsum.photos/seed/dev-portrait/600/600"
            alt="Portrait of a developer"
            className="rounded-lg shadow-2xl object-cover aspect-square"
          />
        </div>
        <div className="md:col-span-3">
          <p className="text-gray-300 text-lg mb-6 leading-relaxed">
            Hello! I'm a passionate frontend developer with a keen eye for UI/UX design. My journey in web development is driven by a love for creating intuitive, dynamic, and beautiful interfaces. I thrive on turning complex problems into simple, elegant solutions.
          </p>
          <p className="text-gray-300 text-lg mb-8 leading-relaxed">
            When I'm not coding, you can find me exploring new design trends, contributing to open-source projects, or experimenting with generative AI.
          </p>
          <div className="flex flex-wrap gap-3">
            {skills.map((skill) => (
              <span
                key={skill}
                className="bg-slate-800 text-cyan-300 text-sm font-medium px-4 py-2 rounded-full"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
