
import React from 'react';
import { GitHubIcon, LinkedInIcon, TwitterIcon } from './icons';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-center justify-between">
        <p className="text-gray-400 text-sm mb-4 sm:mb-0">
          © {new Date().getFullYear()} Digital Canvas. All rights reserved.
        </p>
        <div className="flex space-x-6">
          <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">
            <TwitterIcon className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">
            <GitHubIcon className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">
            <LinkedInIcon className="w-6 h-6" />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
