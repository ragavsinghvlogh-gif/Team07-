
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative text-center py-20 sm:py-32 lg:py-48 min-h-[60vh] flex flex-col items-center justify-center">
        <div className="absolute inset-0 -z-10 h-full w-full bg-slate-900 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="absolute top-0 left-0 h-1/3 w-full bg-gradient-to-b from-slate-900 to-transparent"></div>
        <div className="absolute bottom-0 left-0 h-1/3 w-full bg-gradient-to-t from-slate-900 to-transparent"></div>

      <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
        Crafting Digital Experiences
      </h1>
      <p className="mt-4 max-w-2xl mx-auto text-lg sm:text-xl text-gray-300">
        I design and build beautiful, responsive, and user-centric web applications that bring ideas to life.
      </p>
      <a
        href="#projects"
        className="mt-8 px-8 py-3 bg-cyan-500 text-white font-semibold rounded-lg shadow-lg hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75 transform hover:scale-105 transition-all duration-300"
      >
        View My Work
      </a>
    </section>
  );
};

export default Hero;
