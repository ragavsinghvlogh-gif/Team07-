
import React from 'react';
import type { Project } from '../types';

const projectsData: Project[] = [
  {
    id: 1,
    title: 'E-commerce Platform',
    description: 'A modern, full-featured e-commerce site with a custom CMS and payment integration.',
    imageUrl: 'https://picsum.photos/seed/project1/800/600',
    tags: ['React', 'Node.js', 'Stripe'],
  },
  {
    id: 2,
    title: 'Data Visualization Dashboard',
    description: 'An interactive dashboard for visualizing complex datasets using D3.js and React.',
    imageUrl: 'https://picsum.photos/seed/project2/800/600',
    tags: ['React', 'D3.js', 'TypeScript'],
  },
  {
    id: 3,
    title: 'AI Content Generator',
    description: 'A SaaS application that leverages the Gemini API to generate marketing copy and blog posts.',
    imageUrl: 'https://picsum.photos/seed/project3/800/600',
    tags: ['Next.js', 'Gemini API', 'Tailwind CSS'],
  },
  {
    id: 4,
    title: 'Mobile Fitness App',
    description: 'A cross-platform mobile app for tracking workouts and nutrition.',
    imageUrl: 'https://picsum.photos/seed/project4/800/600',
    tags: ['React Native', 'Firebase'],
  }
];

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => (
  <div className="group relative rounded-xl overflow-hidden bg-slate-800 shadow-lg">
    <img
      src={project.imageUrl}
      alt={project.title}
      className="w-full h-60 object-cover transform group-hover:scale-105 transition-transform duration-500"
    />
    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
    <div className="absolute bottom-0 left-0 p-6">
      <h3 className="text-xl font-bold text-white">{project.title}</h3>
      <p className="text-gray-300 mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        {project.description}
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        {project.tags.map(tag => (
          <span key={tag} className="text-xs font-semibold bg-cyan-500/20 text-cyan-300 px-2 py-1 rounded-full">{tag}</span>
        ))}
      </div>
    </div>
  </div>
);


const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-20 sm:py-24">
      <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12">My Work</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
        {projectsData.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </section>
  );
};

export default Projects;
