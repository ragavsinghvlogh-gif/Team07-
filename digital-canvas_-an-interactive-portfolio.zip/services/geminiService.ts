
import { GoogleGenAI } from "@google/genai";

// Assume process.env.API_KEY is available in the environment
const apiKey = process.env.API_KEY;
if (!apiKey) {
    console.warn("API key not found. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "" });

export const generatePoem = async (topic: string): Promise<string> => {
  if (!apiKey) {
      return Promise.reject(new Error("API key is not configured."));
  }
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a short, elegant, four-line poem about "${topic}". The tone should be slightly mysterious and evocative. Do not include a title.`,
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error generating poem:", error);
    throw new Error("Failed to generate a poem. Please try again.");
  }
};
